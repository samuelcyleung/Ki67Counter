#' Ki67-QC phase 3b (whole section scoring) dataset package
#'
#' @docType package
#' @name ki67p3b
NULL

#' Ki67-QC phase 3b dataset (packaged 2016-12-01)
#'
#' @format raw data; a data frame with ?? rows and ?? columns; each row represents one field (i.e. multiple rows per case); 
#' @name ki67p3b.raw
NULL

#' Ki67-QC phase 3b dataset (packaged 2016-12-01)
#'
#' @format hot-spot scores on whole sections; a data frame with 30 rows and ?? columns; each row represents one case, each column represents one laboratory
#' @name ki67p3b.hp.ws
NULL

#' Ki67-QC phase 3b dataset (packaged 2016-12-01)
#'
#' @format unweighted global scores on whole sections; a data frame with 30 rows and ?? columns; each row represents one case, each column represents one laboratory
#' @name ki67p3b.ug.ws
NULL

#' Ki67-QC phase 3b dataset (packaged 2016-12-01)
#'
#' @format weighted global scores on whole sections; a data frame with 30 rows and ?? columns; each row represents one case, each column represents one laboratory
#' @name ki67p3b.wg.ws
NULL

#' Ki67-QC phase 3b dataset (packaged 2016-12-01)
#'
#' @format hot-spot scores on core-cut biopsies; a data frame with 30 rows and ?? columns; each row represents one case, each column represents one laboratory; 15 cases are from 3A study
#' @name ki67p3b.hp.bx
NULL

#' Ki67-QC phase 3b dataset (packaged 2016-12-01)
#'
#' @format unweighted global scores on core-cut biopsies; a data frame with 30 rows and ?? columns; each row represents one case, each column represents one laboratory; 15 cases are from 3A study
#' @name ki67p3b.ug.bx
NULL

#' Ki67-QC phase 3b dataset (packaged 2016-12-01)
#'
#' @format weighted global scores on core-cut biopsies; a data frame with 30 rows and ?? columns; each row represents one case, each column represents one laboratory; 15 cases are from 3A study
#' @name ki67p3b.wg.bx
NULL