# do qc of Ki67 phase 3B data
# 
# Author: samuelc
###############################################################################
cat("#################\n")
cat("# SOME QC ...    \n")

# double check to see if data from 3a study are the same as the one in ki67p3*.d 
cat("# comparing re-merge 3A data from download data vs. data in repo (expect changes in Q):\n")
cat("# 3A HOT-SPOT integrity check ...\n")
test.3a.hp <- as.data.frame(ki67p3b.hp.bx[which(rownames(ki67p3b.hp.bx)%in%rownames(ki67p3.hp.d)),which(colnames(ki67p3b.hp.bx)%in%colnames(ki67p3.hp.d))],stringsAsFactors=FALSE)
temp <- ki67p3.hp.d[match(rownames(test.3a.hp),rownames(ki67p3.hp.d)),match(colnames(test.3a.hp),colnames(ki67p3.hp.d))]
test.3a.hp$id <- rownames(test.3a.hp)
temp$id <- rownames(temp)
QCFunctions::CompareDb(test.3a.hp, temp,"id")
cat("# 3A UNWEIGHTED-GLOBAL integrity check ...\n")
test.3a.ug <- as.data.frame(ki67p3b.ug.bx[which(rownames(ki67p3b.ug.bx)%in%rownames(ki67p3.ug.d)),which(colnames(ki67p3b.ug.bx)%in%colnames(ki67p3.ug.d))],stringsAsFactors=FALSE)
temp <- ki67p3.ug.d[match(rownames(test.3a.ug),rownames(ki67p3.ug.d)),match(colnames(test.3a.ug),colnames(ki67p3.ug.d))]
test.3a.ug$id <- rownames(test.3a.ug)
temp$id <- rownames(temp)
QCFunctions::CompareDb(test.3a.ug, temp,"id")
cat("# 3A WEIGHTED-GLOBAL integrity check ...\n")
test.3a.wg <- as.data.frame(ki67p3b.wg.bx[which(rownames(ki67p3b.wg.bx)%in%rownames(ki67p3.wg.d)),which(colnames(ki67p3b.wg.bx)%in%colnames(ki67p3.wg.d))],stringsAsFactors=FALSE)
temp <- ki67p3.wg.d[match(rownames(test.3a.wg),rownames(ki67p3.wg.d)),match(colnames(test.3a.wg),colnames(ki67p3.wg.d))]
test.3a.wg$id <- rownames(test.3a.wg)
temp$id <- rownames(temp)
QCFunctions::CompareDb(test.3a.wg, temp,"id")

cat("# make sure ki67p3b.raw is consistent with ...\n") 

cat("ki67p3b.hp.ws ... \n")
test.d <- dplyr::filter(ki67p3b.raw,specimen.type=="surgery" & field.name=="hot-spot")
test.d$count.total <- sapply(test.d$count.total,function(x){min(500,as.numeric(x))})
tempC <- dcast(test.d, surgical.number ~ deid, value.var="count.pos.first.100")
tempT <- dcast(test.d, surgical.number ~ deid, value.var="count.total")
test.d <- mapply(function(count,total){as.numeric(count)/as.numeric(total)*100},tempC[,-1],tempT[,-1])
QCFunctions::CompareDb(
  cbind(test.d,"id"=tempC[,1]), 
  cbind(sapply(ki67p3b.hp.ws,as.numeric),"id"=rownames(ki67p3b.hp.ws)),"id")

cat("ki67p3b.hp.bx ... \n")
test.d <- dplyr::filter(ki67p3b.raw,specimen.type=="biopsy" & field.name=="hot-spot")
test.d$count.total <- sapply(test.d$count.total,function(x){min(500,as.numeric(x))})
tempC <- dcast(test.d, surgical.number ~ deid, value.var="count.pos.first.100")
tempT <- dcast(test.d, surgical.number ~ deid, value.var="count.total")
test.d <- mapply(function(count,total){as.numeric(count)/as.numeric(total)*100},tempC[,-1],tempT[,-1])
QCFunctions::CompareDb(
    cbind(test.d,"id"=tempC[,1]), 
    cbind(sapply(ki67p3b.hp.bx,as.character),"id"=rownames(ki67p3b.hp.bx)),"id")

cat("ki67p3b.ug.ws ...\n")
test.d <- dplyr::filter(ki67p3b.raw,specimen.type=="surgery" & field.name!="hot-spot")
test.d$count.total <- sapply(test.d$count.total,function(x){min(100,as.numeric(x))})
test.d$count.pos.first.100 <- as.numeric(test.d$count.pos.first.100)
tempC <- dcast(test.d, surgical.number ~ deid, value.var="count.pos.first.100", sum)
tempT <- dcast(test.d, surgical.number ~ deid, value.var="count.total",         sum)
test.d <- mapply(function(count,total){as.numeric(count)/as.numeric(total)*100},tempC[,-1],tempT[,-1])
QCFunctions::CompareDb(
    cbind(test.d,"id"=tempC[,1]), 
    cbind(sapply(ki67p3b.ug.ws,as.character),"id"=rownames(ki67p3b.ug.ws)),"id")

cat("ki67p3b.ug.bx ...\n")
test.d <- dplyr::filter(ki67p3b.raw,specimen.type=="biopsy" & field.name!="hot-spot")
test.d$count.total <- sapply(test.d$count.total,function(x){min(100,as.numeric(x))})
test.d$count.pos.first.100 <- as.numeric(test.d$count.pos.first.100)
tempC <- dcast(test.d, surgical.number ~ deid, value.var="count.pos.first.100", sum)
tempT <- dcast(test.d, surgical.number ~ deid, value.var="count.total",         sum)
test.d <- mapply(function(count,total){as.numeric(count)/as.numeric(total)*100},tempC[,-1],tempT[,-1])
QCFunctions::CompareDb(
    cbind(test.d,"id"=tempC[,1]), 
    cbind(sapply(ki67p3b.ug.bx,as.character),"id"=rownames(ki67p3b.ug.bx)),"id")

get.field.col.in.test.d <- function(x){
  switch(x,
      "high"="slide.pp.high",
      "medium"="slide.pp.med",
      "low"="slide.pp.low",
      "negative"="slide.pp.neg" 
  )
}

cat("ki67p3b.wg.ws ...\n")
test.d <- dplyr::filter(ki67p3b.raw,specimen.type=="surgery" & field.name!="hot-spot")
test.d$count.total <- sapply(test.d$count.total,function(x){min(100,as.numeric(x))})
test.d$count.pos.first.100 <- as.numeric(test.d$count.pos.first.100)
possible.field.name <- unique(test.d$field.name)
temp <- dcast(test.d, surgical.number ~ deid, value.var="count.pos.first.100", sum)
for (i in 1:nrow(temp)) {
  for (j in 2:ncol(temp)) {
    surgical.number <- temp[i,"surgical.number"]
    deid <- colnames(temp)[j]
    temp[i,j] <- as.character(sum(sapply(possible.field.name,function(field.name){
      temp2 <- test.d[test.d$surgical.number==surgical.number & test.d$deid==deid & test.d$field.name==field.name,c("count.pos.first.100","count.total",get.field.col.in.test.d(field.name))]
      if (nrow(temp2)>0) {
        temp3 <- (apply(temp2[,c(1:2)],2,function(x){sum(as.numeric(x))}))
        return(as.numeric(temp3[1])/as.numeric(temp3[2])*as.numeric(temp2[1,3])/100)
      } else {
        return(0)
      }
    }))*100)
  }
}
QCFunctions::CompareDb(
    cbind(temp[,-1],"id"=temp[,1],stringsAsFactors=FALSE), 
    cbind(sapply(ki67p3b.wg.ws,as.character),"id"=rownames(ki67p3b.wg.ws),stringsAsFactors=FALSE),"id")

cat("ki67p3b.wg.bx ...\n")
test.d <- dplyr::filter(ki67p3b.raw,specimen.type=="biopsy" & field.name!="hot-spot")
test.d$count.total <- sapply(test.d$count.total,function(x){min(100,as.numeric(x))})
test.d$count.pos.first.100 <- as.numeric(test.d$count.pos.first.100)
possible.field.name <- unique(test.d$field.name)
temp <- dcast(test.d, surgical.number ~ deid, value.var="count.pos.first.100", sum)
for (i in 1:nrow(temp)) {
  for (j in 2:ncol(temp)) {
    surgical.number <- temp[i,"surgical.number"]
    deid <- colnames(temp)[j]
    temp[i,j] <- as.character(sum(sapply(possible.field.name,function(field.name){
      temp2 <- test.d[test.d$surgical.number==surgical.number & test.d$deid==deid & test.d$field.name==field.name,c("count.pos.first.100","count.total",get.field.col.in.test.d(field.name))]
      if (nrow(temp2)>0) {
        temp3 <- (apply(temp2[,c(1:2)],2,function(x){sum(as.numeric(x))}))
        return(as.numeric(temp3[1])/as.numeric(temp3[2])*as.numeric(temp2[1,3])/100)
      } else {
        return(0)
      }
    }))*100)
  }
}
QCFunctions::CompareDb(
    cbind(temp[,-1],"id"=temp[,1],stringsAsFactors=FALSE), 
    cbind(sapply(ki67p3b.wg.bx,as.character),"id"=rownames(ki67p3b.wg.bx),stringsAsFactors=FALSE),"id")


#######################
### other QC        ###

cat("# make sure slide.pp.high/low/med/neg adds up to 100 ...\n")
for (surgical.number in unique(ki67p3b.raw$surgical.number)) {
  for (deid in unique(ki67p3b.raw$deid)) {
    for (specimen.type in unique(ki67p3b.raw$specimen.type)) {
      temp.d <- ki67p3b.raw[
        which(ki67p3b.raw$deid==deid & 
              ki67p3b.raw$surgical.number==surgical.number & 
              ki67p3b.raw$field.name!="hot-spot" & 
              ki67p3b.raw$specimen.type==specimen.type),]
      if(nrow(temp.d)!=0) { # some labs did not score core biopsy
        if (sum(as.numeric(apply(temp.d[,c("slide.pp.high","slide.pp.med","slide.pp.low","slide.pp.neg")],2,unique)))!=100) {
          cat(deid,"specified slide percentages sum!=100 for",surgical.number,"-",specimen.type,"\n")
          print(apply(temp.d[,c("slide.pp.high","slide.pp.med","slide.pp.low","slide.pp.neg")],2,unique))
        }
      }
    }
  }
}
cat("done.\n")

cat("# make sure hot-spot exist for each slide for each scorer ...\n")
for (surgical.number in unique(ki67p3b.raw$surgical.number)) {
  for (deid in unique(ki67p3b.raw$deid)) {
    for (specimen.type in unique(ki67p3b.raw$specimen.type)) {
      if (!(specimen.type=="biopsy" & deid %in% c("E","X","A"))) { # some labs did not score biopsy
        if (length(which(
              ki67p3b.raw$deid==deid & 
                  ki67p3b.raw$surgical.number==surgical.number & 
                  ki67p3b.raw$field.name=="hot-spot" & 
                  ki67p3b.raw$specimen.type==specimen.type))==0) {
          cat(deid,"did not score hot-spot for",surgical.number,"-",specimen.type,"\n")
        }
      }
    }
  }
}
cat("done.\n")

### end of other OC ###
#######################


### diff with the MOST RECENT previous export ###
qc_dir <- file.path(getwd(),"export_logs")
kd_archs <- dir(qc_dir)[grep("kd_.*rda",dir(qc_dir))]
latest_kd_arch <- kd_archs[order(sapply(strsplit(kd_archs,"_|\\."),function(x){return(as.Date(x[2]))}),decreasing=TRUE)[1]]
load(file.path(getwd(),"export_logs",latest_kd_arch))

prev.d <- kd; 
new.d <- ki67p3b.raw;

prev.d$unique_id <- paste(prev.d$deid, prev.d$surgical.number, prev.d$field.x, prev.d$field.y)
new.d$unique_id  <- paste(new.d$deid,  new.d$surgical.number,  new.d$field.x,  new.d$field.y)

cat("\n")
cat("########################################\n")
cat("### compare with previously sent: ",latest_kd_arch,"...\n")
QCFunctions::CompareDb(prev.d, new.d,"unique_id")
cat("### end of compare with previously sent.\n")
cat("########################################\n")


cat("# END OF SOME QC ...\n")
cat("####################\n")