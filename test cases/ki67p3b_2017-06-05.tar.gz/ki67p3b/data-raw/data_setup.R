# link and setup Ki67 phase 3b database
# also do some QC
# started 2016-07-14
#
# Author: samuelc
###############################################################################
QC.OUTPUT.DIR <- "C:\\Users\\samle\\OneDrive\\Documents\\gpec\\Ki67-QC\\phase3b\\RESULTS\\"
library(xlsx)
library(ki67p3) # get 3A results for the 15 biopsy
library(assertthat)
library(dplyr)
library(reshape2)
data(ki67p3.hp.d)
data(ki67p3.ug.d)
data(ki67p3.wg.d)
data(ki67p3.raw.d)

LIB.DIR <- "C:\\Users\\samle\\Documents\\workspace\\R\\R_scripts\\"
curr.dir <- getwd()
setwd(paste(LIB.DIR,"misc/",sep=""))
source("plot_helpers.R")
setwd(curr.dir) # change directory back to current directory !!!


# some constants
TMADB.TIME.FORMAT.PDT <- "%B %d, %Y %I:%M:%S PDT %p" # format of the time string exported from TMADB
TMADB.TIME.FORMAT.PST <- "%B %d, %Y %I:%M:%S PST %p" # format of the time string exported from TMADB
PARSE.TMADB.TIME.STRING <- function(x){
	if (length(grep("PDT",x)==1)) {
		return(strptime(x,format=TMADB.TIME.FORMAT.PDT))
	} else {
		return(strptime(x,format=TMADB.TIME.FORMAT.PST))
	}
}
WS.LAB.IDS <- c("E","H","B","F","G","V","R","P","O","L","T","K","A","U","M","I","D","J","S","W","N","Q","X")
BX.LAB.IDS <- c(    "H","B","F","G","V","R","P","O","L","T","K","A","U","M","I","D","J","S","W","N","Q"    )

# define data file location
SCORES.DIR <- "raw\\"

# whole section
SCORES.FILENAME.E.WS <- paste(SCORES.DIR,"hugh\\scoring_session_scores_id232.txt",sep=""); # Judith C. Hugh (WS ONLY); group 1
SCORES.FILENAME.H.WS <- paste(SCORES.DIR,"fineberg\\scoring_session_scores_id237.txt",sep=""); # Susan Fineberg; group 1
SCORES.FILENAME.B.WS <- paste(SCORES.DIR,"chang\\scoring_session_scores_id230.txt",sep=""); # Martin C. Chang; group 1
SCORES.FILENAME.F.WS <- paste(SCORES.DIR,"kos\\scoring_session_scores_id233.txt",sep=""); # Zuzana Kos; group 1
SCORES.FILENAME.G.WS <- paste(SCORES.DIR,"nofech-mozes\\scoring_session_scores_id235.txt",sep=""); # Sharon Nofech-Mozes; group 1
SCORES.FILENAME.V.WS <- paste(SCORES.DIR,"starczynski\\scoring_session_scores_id308.txt",sep=""); # Jane Starczynski; group 1

SCORES.FILENAME.R.WS <- paste(SCORES.DIR,"mastropasqua\\scoring_session_scores_id257.txt",sep=""); # Mauro G. Mastropasqua; group 2
SCORES.FILENAME.P.WS <- paste(SCORES.DIR,"sakatani\\scoring_session_scores_id253.txt",sep=""); # Takashi Sakatani; group 2
SCORES.FILENAME.O.WS <- paste(SCORES.DIR,"moriya\\scoring_session_scores_id251.txt",sep=""); # Takuya Moriya; group 2
SCORES.FILENAME.L.WS <- paste(SCORES.DIR,"salgado\\scoring_session_scores_id245.txt",sep=""); # Roberto Salgado; group 2
SCORES.FILENAME.T.WS <- paste(SCORES.DIR,"piper\\scoring_session_scores_id261.txt",sep=""); # Tammy Piper; group 2
SCORES.FILENAME.K.WS <- paste(SCORES.DIR,"zabaglo\\scoring_session_scores_id243.txt",sep=""); # Lila Zabaglo; group 2
SCORES.FILENAME.A.WS <- paste(SCORES.DIR,"gown\\scoring_session_scores_id310.txt",sep=""); # Allen Gown; group 2

SCORES.FILENAME.U.WS <- paste(SCORES.DIR,"laenkholm\\scoring_session_scores_id263.txt",sep=""); # Anne-Vibeke L�nkholm; group 3
SCORES.FILENAME.M.WS <- paste(SCORES.DIR,"penault-llorca\\scoring_session_scores_id247.txt",sep=""); # Fr�d�rique M. Penault-Llorca; group 3
SCORES.FILENAME.I.WS <- paste(SCORES.DIR,"bane\\scoring_session_scores_id239.txt",sep=""); # Anita Bane; group 3
SCORES.FILENAME.D.WS <- paste(SCORES.DIR,"gutierrez\\scoring_session_scores_id306.txt",sep=""); # Carolina Gutierrez; group 3
SCORES.FILENAME.J.WS <- paste(SCORES.DIR,"gao\\scoring_session_scores_id314.txt",sep=""); # Doris Gao; group 3

SCORES.FILENAME.S.WS <- paste(SCORES.DIR,"focke\\scoring_session_scores_id259.txt",sep=""); # Cornelia Marlene Focke; group 4
SCORES.FILENAME.W.WS <- paste(SCORES.DIR,"van der Vegt\\scoring_session_scores_id267.txt",sep=""); # Bert van der Vegt; group 4
SCORES.FILENAME.N.WS <- paste(SCORES.DIR,"arun\\scoring_session_scores_id249.txt",sep=""); # Indu Arun; group 4
SCORES.FILENAME.Q.WS <- paste(SCORES.DIR,"ehinger\\scoring_session_scores_id255.txt",sep=""); # Anna Ehinger; group 4
SCORES.FILENAME.X.WS <- paste(SCORES.DIR,"badve\\scoring_session_scores_id312.txt",sep=""); # Sunil Badve; group 4

# core biopsy
SCORES.FILENAME.H.BX <- paste(SCORES.DIR,"fineberg\\scoring_session_scores_id238.txt",sep=""); # Susan Fineberg; group 1
SCORES.FILENAME.B.BX <- paste(SCORES.DIR,"chang\\scoring_session_scores_id231.txt",sep=""); # Martin C. Chang; group 1
SCORES.FILENAME.F.BX <- paste(SCORES.DIR,"kos\\scoring_session_scores_id234.txt",sep=""); # Zuzana Kos; group 1
SCORES.FILENAME.G.BX <- paste(SCORES.DIR,"nofech-mozes\\scoring_session_scores_id236.txt",sep=""); # Sharon Nofech-Mozes; group 1
SCORES.FILENAME.V.BX <- paste(SCORES.DIR,"starczynski\\scoring_session_scores_id309.txt",sep=""); # Jane Starczynski; group 1

SCORES.FILENAME.R.BX <- paste(SCORES.DIR,"mastropasqua\\scoring_session_scores_id258.txt",sep=""); # Mauro G. Mastropasqua; group 2
SCORES.FILENAME.P.BX <- paste(SCORES.DIR,"sakatani\\scoring_session_scores_id254.txt",sep=""); # Takashi Sakatani; group 2
SCORES.FILENAME.O.BX <- paste(SCORES.DIR,"moriya\\scoring_session_scores_id252.txt",sep=""); # Takuya Moriya; group 2
SCORES.FILENAME.L.BX <- paste(SCORES.DIR,"salgado\\scoring_session_scores_id246.txt",sep=""); # Roberto Salgado; group 2
SCORES.FILENAME.T.BX <- paste(SCORES.DIR,"piper\\scoring_session_scores_id262.txt",sep=""); # Tammy Piper; group 2
SCORES.FILENAME.K.BX <- paste(SCORES.DIR,"zabaglo\\scoring_session_scores_id244.txt",sep=""); # Lila Zabaglo; group 2
SCORES.FILENAME.A.BX <- paste(SCORES.DIR,"gown\\scoring_session_scores_id311.txt",sep=""); # Allen Gown; group 2

SCORES.FILENAME.U.BX <- paste(SCORES.DIR,"laenkholm\\scoring_session_scores_id264.txt",sep=""); # Anne-Vibeke L�nkholm; group 3
SCORES.FILENAME.M.BX <- paste(SCORES.DIR,"penault-llorca\\scoring_session_scores_id248.txt",sep=""); # Fr�d�rique M. Penault-Llorca; group 3
SCORES.FILENAME.I.BX <- paste(SCORES.DIR,"bane\\scoring_session_scores_id240.txt",sep=""); # Anita Bane; group 3
SCORES.FILENAME.D.BX <- paste(SCORES.DIR,"gutierrez\\scoring_session_scores_id307.txt",sep=""); # Carolina Gutierrez; group 3
SCORES.FILENAME.J.BX <- paste(SCORES.DIR,"gao\\scoring_session_scores_id315.txt",sep=""); # Doris Gao; group 3

SCORES.FILENAME.S.BX <- paste(SCORES.DIR,"focke\\scoring_session_scores_id260.txt",sep=""); # Cornelia Marlene Focke; group 4
SCORES.FILENAME.W.BX <- paste(SCORES.DIR,"van der Vegt\\scoring_session_scores_id268.txt",sep=""); # Bert van der Vegt; group 4
SCORES.FILENAME.N.BX <- paste(SCORES.DIR,"arun\\scoring_session_scores_id250.txt",sep=""); # Indu Arun; group 4
SCORES.FILENAME.Q.BX <- paste(SCORES.DIR,"ehinger\\scoring_session_scores_id256.txt",sep=""); # Anna Ehinger; group 4

# 3A data
SCORES.FILENAME.H.BX.3A <- paste(SCORES.DIR,"fineberg\\scoring_session_scores_id178.txt",sep=""); # Susan Fineberg; group 1
SCORES.FILENAME.B.BX.3A <- paste(SCORES.DIR,"chang\\scoring_session_scores_id152.txt",sep=""); # Martin C. Chang; group 1
SCORES.FILENAME.F.BX.3A <- paste(SCORES.DIR,"kos\\scoring_session_scores_id168.txt",sep=""); # Zuzana Kos; group 1
SCORES.FILENAME.G.BX.3A <- paste(SCORES.DIR,"nofech-mozes\\scoring_session_scores_id173.txt",sep=""); # Sharon Nofech-Mozes; group 1
SCORES.FILENAME.V.BX.3A <- paste(SCORES.DIR,"starczynski\\scoring_session_scores_id192.txt",sep=""); # Jane Starczynski; group 1

SCORES.FILENAME.R.BX.3A <- paste(SCORES.DIR,"mastropasqua\\scoring_session_scores_id176.txt",sep=""); # Mauro G. Mastropasqua; group 2
SCORES.FILENAME.P.BX.3A <- paste(SCORES.DIR,"sakatani\\scoring_session_scores_id167.txt",sep=""); # Takashi Sakatani; group 2
SCORES.FILENAME.O.BX.3A <- paste(SCORES.DIR,"moriya\\scoring_session_scores_id163.txt",sep=""); # Takuya Moriya; group 2
SCORES.FILENAME.L.BX.3A <- paste(SCORES.DIR,"salgado\\scoring_session_scores_id145.txt",sep=""); # Roberto Salgado; group 2
SCORES.FILENAME.T.BX.3A <- paste(SCORES.DIR,"piper\\scoring_session_scores_id185.txt",sep=""); # Tammy Piper; group 2
SCORES.FILENAME.K.BX.3A <- paste(SCORES.DIR,"zabaglo\\scoring_session_scores_id157.txt",sep=""); # Lila Zabaglo; group 2
SCORES.FILENAME.A.BX.3A <- paste(SCORES.DIR,"gown\\scoring_session_scores_id139.txt",sep=""); # Allen Gown; group 2

SCORES.FILENAME.U.BX.3A <- paste(SCORES.DIR,"laenkholm\\scoring_session_scores_id190.txt",sep=""); # Anne-Vibeke L�nkholm; group 3
SCORES.FILENAME.M.BX.3A <- paste(SCORES.DIR,"penault-llorca\\scoring_session_scores_id142.txt",sep=""); # Fr�d�rique M. Penault-Llorca; group 3
SCORES.FILENAME.I.BX.3A <- paste(SCORES.DIR,"bane\\scoring_session_scores_id183.txt",sep=""); # Anita Bane; group 3
SCORES.FILENAME.D.BX.3A <- paste(SCORES.DIR,"gutierrez\\scoring_session_scores_id159.txt",sep=""); # Carolina Gutierrez; group 3
SCORES.FILENAME.J.BX.3A <- paste(SCORES.DIR,"gao\\scoring_session_scores_id194.txt",sep=""); # Doris Gao; group 3

SCORES.FILENAME.S.BX.3A <- paste(SCORES.DIR,"focke\\scoring_session_scores_id180.txt",sep=""); # Cornelia Marlene Focke; group 4
SCORES.FILENAME.W.BX.3A <- paste(SCORES.DIR,"van der Vegt\\scoring_session_scores_id297.txt",sep=""); # Bert van der Vegt; group 4
SCORES.FILENAME.N.BX.3A <- paste(SCORES.DIR,"arun\\scoring_session_scores_id154.txt",sep=""); # Indu Arun; group 4
SCORES.FILENAME.Q.BX.3A <- paste(SCORES.DIR,"ehinger\\scoring_session_scores_id296.txt",sep=""); # Anna Ehinger; group 4

# read data file - summarized scores
for (lab.id in WS.LAB.IDS) {assign(paste(tolower(lab.id),".raw.ws",   sep=""),read.delim(file=get(paste("SCORES.FILENAME.",lab.id,".WS",   sep="")), sep="\t", header=T, as.is=T))}
for (lab.id in BX.LAB.IDS) {assign(paste(tolower(lab.id),".raw.bx",   sep=""),read.delim(file=get(paste("SCORES.FILENAME.",lab.id,".BX",   sep="")), sep="\t", header=T, as.is=T))}
for (lab.id in BX.LAB.IDS) {assign(paste(tolower(lab.id),".raw.bx.3a",sep=""),read.delim(file=get(paste("SCORES.FILENAME.",lab.id,".BX.3A",sep="")), sep="\t", header=T, as.is=T))}

# read data file - raw count
for (lab.id in WS.LAB.IDS) {assign(paste(tolower(lab.id),".raw.ct.ws",   sep=""),read.delim(file=sub("scores","nuclei_selections",get(paste("SCORES.FILENAME.",lab.id,".WS",   sep=""))), sep="\t", header=T, as.is=T))}
for (lab.id in BX.LAB.IDS) {assign(paste(tolower(lab.id),".raw.ct.bx",   sep=""),read.delim(file=sub("scores","nuclei_selections",get(paste("SCORES.FILENAME.",lab.id,".BX",   sep=""))), sep="\t", header=T, as.is=T))}
for (lab.id in BX.LAB.IDS) {assign(paste(tolower(lab.id),".raw.ct.bx.3a",sep=""),read.delim(file=sub("scores","nuclei_selections",get(paste("SCORES.FILENAME.",lab.id,".BX.3A",sep=""))), sep="\t", header=T, as.is=T))}

# make sure all raw.ws have same numebr of rows - this ensure that the files are 
# read corrected e.g. not affected by possible newline character in comments
assert_that(sum(sapply(ls()[grep("raw.ws",ls())],function(x){nrow(get(x))})==30)==length(WS.LAB.IDS))
assert_that(sum(sapply(ls()[grep("raw.bx$",ls())],function(x){nrow(get(x))})==15)==length(grep("raw.bx$",ls())))
assert_that(sum(sapply(ls()[grep("raw.bx.3a",ls())],function(x){nrow(get(x))})%in%c(15,30))==length(grep("raw.bx.3a",ls())))

# specimen number
specimen.number.map <- read.xlsx(file=file.path(SCORES.DIR,"Ki673b case anonymized key.xlsx"),sheetName="Sheet1",stringsAsFactors=FALSE)
specimen.number.map <- specimen.number.map[,c("actual.case.number", "anonymized.case.number")]
# need to add 3a study to specimen.number.map
specimen.number.map <- rbind(
  specimen.number.map,
  cbind("actual.case.number"=w.raw.bx.3a$Surgical.number,"anonymized.case.number"=w.raw.bx.3a$Surgical.number)
)

# for the 3a data, need to remove all rows that are NOT part of the 3b study
for (lab.id in BX.LAB.IDS) {
  obj_name <- paste(tolower(lab.id),".raw.bx.3a",sep="")
  temp <- get(obj_name)
  assign(obj_name,temp[temp$Surgical.number%in%specimen.number.map$actual.case.number,])
}
for (lab.id in BX.LAB.IDS) {
  obj_name <- paste(tolower(lab.id),".raw.ct.bx.3a",sep="")
  temp <- get(obj_name)
  assign(obj_name,temp[temp$Surgical.number%in%specimen.number.map$actual.case.number,])
}
assert_that(sum(sapply(ls()[grep("raw.bx.3a",ls())],function(x){nrow(get(x))})==15)==length(grep("raw.bx.3a",ls())))

# merge 3a data with bx
for (lab.id in BX.LAB.IDS) {
  obj_name <- paste(tolower(lab.id),".raw.bx",sep="")
  temp3b <- get(obj_name)
  temp3a <- get(paste(tolower(lab.id),".raw.bx.3a",sep=""))
  assert_that(sum(colnames(temp3a)==colnames(temp3b))==ncol(temp3a))
  assign(obj_name,rbind(temp3b,temp3a))
}
for (lab.id in BX.LAB.IDS) {
  obj_name <- paste(tolower(lab.id),".raw.ct.bx",sep="")
  temp3b <- get(obj_name)
  temp3a <- get(paste(tolower(lab.id),".raw.ct.bx.3a",sep=""))
  assert_that(sum(colnames(temp3a)==colnames(temp3b))==ncol(temp3a))
  assign(obj_name,rbind(temp3b,temp3a))
}

# parse scores
# NOTE: fields could contain >100 nuclei count - need update!!!
source("parse_scores.R")

# qc plots ...
pdf(paste(QC.OUTPUT.DIR,"qc_plots_",format(Sys.Date(),format="%Y-%m-%d"),".pdf",sep=""),width=14,height=14)
num.ws <- 30
num.bx <- 30
qc.hp.ws <- matrix(rep(NA,length(WS.LAB.IDS)*num.ws),nrow=num.ws)
qc.ug.ws <- qc.hp.ws
qc.wg.ws <- qc.hp.ws
colnames(qc.hp.ws) <- paste(WS.LAB.IDS,"(WS-HP)" ); for (lab.id in WS.LAB.IDS) qc.hp.ws[,which(WS.LAB.IDS%in%lab.id)] <- get(paste(tolower(lab.id),".hp.ws",sep=""))
colnames(qc.ug.ws) <- paste(WS.LAB.IDS,"(WS-UK)" ); for (lab.id in WS.LAB.IDS) qc.ug.ws[,which(WS.LAB.IDS%in%lab.id)] <- get(paste(tolower(lab.id),".ug.ws",sep=""))
colnames(qc.wg.ws) <- paste(WS.LAB.IDS,"(WS-NCI)"); for (lab.id in WS.LAB.IDS) qc.wg.ws[,which(WS.LAB.IDS%in%lab.id)] <- get(paste(tolower(lab.id),".wg.ws",sep=""))
pairs(qc.hp.ws,upper.panel=panel.spearman.cor)
pairs(qc.ug.ws,upper.panel=panel.spearman.cor)
pairs(qc.wg.ws,upper.panel=panel.spearman.cor)

qc.hp.bx <- matrix(rep(NA,length(BX.LAB.IDS)*num.bx),nrow=num.bx)
qc.ug.bx <- qc.hp.bx
qc.wg.bx <- qc.hp.bx
colnames(qc.hp.bx) <- paste(BX.LAB.IDS,"(BX-HP)" ); for (lab.id in BX.LAB.IDS) qc.hp.bx[,which(BX.LAB.IDS%in%lab.id)] <- get(paste(tolower(lab.id),".hp.bx",sep=""))
colnames(qc.ug.bx) <- paste(BX.LAB.IDS,"(BX-UK)" ); for (lab.id in BX.LAB.IDS) qc.ug.bx[,which(BX.LAB.IDS%in%lab.id)] <- get(paste(tolower(lab.id),".ug.bx",sep=""))
colnames(qc.wg.bx) <- paste(BX.LAB.IDS,"(BX-NCI)"); for (lab.id in BX.LAB.IDS) qc.wg.bx[,which(BX.LAB.IDS%in%lab.id)] <- get(paste(tolower(lab.id),".wg.bx",sep=""))
pairs(qc.hp.bx,upper.panel=panel.spearman.cor)
pairs(qc.ug.bx,upper.panel=panel.spearman.cor)
pairs(qc.wg.bx,upper.panel=panel.spearman.cor)
dev.off()

cat("# make sure surgical numbers are in the same order for ALL data ... ")
check <- TRUE
for (i in 2:length(WS.LAB.IDS)) {
  check <- check & 
      (sum(get(paste0(tolower(WS.LAB.IDS[1]),".raw.ws"))$Surgical.number==get(paste0(tolower(WS.LAB.IDS[i]),".raw.ws"))$Surgical.number)==nrow(get(paste0(tolower(WS.LAB.IDS[1]),".raw.ws"))))
}
for (i in 2:length(BX.LAB.IDS)) {
  check <- check & 
      (sum(get(paste0(tolower(BX.LAB.IDS[1]),".raw.bx"))$Surgical.number==get(paste0(tolower(BX.LAB.IDS[i]),".raw.bx"))$Surgical.number)==nrow(get(paste0(tolower(BX.LAB.IDS[1]),".raw.bx"))))
}
cat(check,".\n")

################################################################################
# export data ------------------------------------------------------------------

specimen.numbers <- specimen.number.map$actual.case.number[match(get(paste0(tolower(WS.LAB.IDS[1]),".raw.ws"))$Surgical.number,specimen.number.map$anonymized.case.number)]

ki67p3b.hp.ws <- qc.hp.ws; rownames(ki67p3b.hp.ws) <- specimen.numbers
ki67p3b.ug.ws <- qc.ug.ws; rownames(ki67p3b.ug.ws) <- specimen.numbers
ki67p3b.wg.ws <- qc.wg.ws; rownames(ki67p3b.wg.ws) <- specimen.numbers

# format colnames
colnames(ki67p3b.hp.ws) <- sapply(colnames(ki67p3b.hp.ws),function(x){strsplit(x," ")[[1]][1]},USE.NAMES=FALSE)
colnames(ki67p3b.ug.ws) <- sapply(colnames(ki67p3b.ug.ws),function(x){strsplit(x," ")[[1]][1]},USE.NAMES=FALSE)
colnames(ki67p3b.wg.ws) <- sapply(colnames(ki67p3b.wg.ws),function(x){strsplit(x," ")[[1]][1]},USE.NAMES=FALSE)

ki67p3b.hp.ws <- as.data.frame(ki67p3b.hp.ws, stringsAsFactors=FALSE)
ki67p3b.ug.ws <- as.data.frame(ki67p3b.ug.ws, stringsAsFactors=FALSE)
ki67p3b.wg.ws <- as.data.frame(ki67p3b.wg.ws, stringsAsFactors=FALSE)

specimen.numbers <- specimen.number.map$actual.case.number[match(get(paste0(tolower(BX.LAB.IDS[1]),".raw.bx"))$Surgical.number,specimen.number.map$anonymized.case.number)]

ki67p3b.hp.bx <- qc.hp.bx; rownames(ki67p3b.hp.bx) <- specimen.numbers
ki67p3b.ug.bx <- qc.ug.bx; rownames(ki67p3b.ug.bx) <- specimen.numbers
ki67p3b.wg.bx <- qc.wg.bx; rownames(ki67p3b.wg.bx) <- specimen.numbers

colnames(ki67p3b.hp.bx) <- sapply(colnames(ki67p3b.hp.bx),function(x){strsplit(x," ")[[1]][1]},USE.NAMES=FALSE)
colnames(ki67p3b.ug.bx) <- sapply(colnames(ki67p3b.ug.bx),function(x){strsplit(x," ")[[1]][1]},USE.NAMES=FALSE)
colnames(ki67p3b.wg.bx) <- sapply(colnames(ki67p3b.wg.bx),function(x){strsplit(x," ")[[1]][1]},USE.NAMES=FALSE)

# rename surgical number of bx to match ws 
rownames(ki67p3b.hp.bx) <- sapply(rownames(ki67p3b.hp.bx),function(x){sub("C","",x)},USE.NAMES=FALSE)
rownames(ki67p3b.ug.bx) <- sapply(rownames(ki67p3b.ug.bx),function(x){sub("C","",x)},USE.NAMES=FALSE)
rownames(ki67p3b.wg.bx) <- sapply(rownames(ki67p3b.wg.bx),function(x){sub("C","",x)},USE.NAMES=FALSE)

# reorder rows of *.bx to match *.ws
ki67p3b.hp.bx <- as.data.frame(ki67p3b.hp.bx[match(rownames(ki67p3b.hp.ws),rownames(ki67p3b.hp.bx)),],stringsAsFactors=FALSE)
ki67p3b.ug.bx <- as.data.frame(ki67p3b.ug.bx[match(rownames(ki67p3b.ug.ws),rownames(ki67p3b.ug.bx)),],stringsAsFactors=FALSE)
ki67p3b.wg.bx <- as.data.frame(ki67p3b.wg.bx[match(rownames(ki67p3b.wg.ws),rownames(ki67p3b.wg.bx)),],stringsAsFactors=FALSE)

# shows which labs differ between full count or first 100 counts
sapply(BX.LAB.IDS,function(x){sum( get(paste0(tolower(x),".wg.bx")) == get(paste0(tolower(x),".wg.bx.ct")) )})

#ki67p3b.clin.d

# generate ki67p3b.raw ---------------------------------------------------------
ki67p3b.raw <- c()
for (deid in colnames(ki67p3b.hp.ws)) {
  for (specimen.type in c("surgery","biopsy")) {
    ws <- NULL
    if (specimen.type == "surgery") {
      ws <- get(paste0(tolower(deid),".ws.ct"))
    } else if (deid %in% BX.LAB.IDS){
      ws <- get(paste0(tolower(deid),".bx.ct"))
    }
    if (!is.null(ws)) {
      institution <- ki67p3.raw.d$institution[ki67p3.raw.d$deid==deid][1]
      if (deid=="W") {institution <- "NL.UMCG"} # W not in phase 3A!
      if (deid=="X") {institution <- "US.Indiana"} # W not in phase 3A!
      group.num <- ws[[1]]$group.num
      for (i in 1:length(ws)) {
        surgical.number <- specimen.number.map$actual.case.number[which(specimen.number.map$anonymized.case.number==ws[[i]]$surgical.number)]
        surgical.number <- sub("C","",surgical.number) # for matching bx to ws 
        slide.id <- ws[[i]]$slide.id
        slide.pp.high <- ws[[i]]$slide.pps$high
        slide.pp.med  <- ws[[i]]$slide.pps$medium
        slide.pp.low  <- ws[[i]]$slide.pps$low
        slide.pp.neg  <- ws[[i]]$slide.pps$negative
        comment.slide <- ws[[i]]$comment.on.whole.slide
        # hotspot ...
        field.name <- ws[[i]][["hotspot"]]$name
        count.pos  <- ws[[i]][["hotspot"]]$count.pos
        count.total<- ws[[i]][["hotspot"]]$count.total
        count.pos.first.100<- ws[[i]][["hotspot"]]$count.pos500
        field.x <- ws[[i]][["hotspot"]]$x
        field.y <- ws[[i]][["hotspot"]]$y
        field.diameter <- ws[[i]][["hotspot"]]$diameter
        comment.field <- ws[[i]][["hotspot"]]$comment
        ki67p3b.raw <- rbind(ki67p3b.raw,c(deid,institution,group.num,surgical.number,specimen.type,slide.id,slide.pp.high,slide.pp.med,slide.pp.low,slide.pp.neg,field.name,count.pos,count.total,count.pos.first.100,field.x,field.y,field.diameter,comment.slide,comment.field))
        # fields ...
        for (j in 1:length(ws[[i]]$fields)) {
          field.name <- ws[[i]]$fields[[j]]$name
          count.pos  <- ws[[i]]$fields[[j]]$count.pos
          count.total<- ws[[i]]$fields[[j]]$count.total
          count.pos.first.100<- ws[[i]]$fields[[j]]$count.pos100
          field.x <- ws[[i]]$fields[[j]]$x
          field.y <- ws[[i]]$fields[[j]]$y
          field.diameter <- ws[[i]]$fields[[j]]$diameter	
          comment.field <- ws[[i]]$fields[[j]]$comment
          ki67p3b.raw <- rbind(ki67p3b.raw,c(deid,institution,group.num,surgical.number,specimen.type,slide.id,slide.pp.high,slide.pp.med,slide.pp.low,slide.pp.neg,field.name,count.pos,count.total,count.pos.first.100,field.x,field.y,field.diameter,comment.slide,comment.field))
        }
      }
    } else { # is.null(ws) - i.e. this is from phase 3a study
      
    }
  }
}
colnames(ki67p3b.raw) <- c(
    "deid",
    "institution",
    "group.num",
    "surgical.number",
    "specimen.type",
    "slide.id",
    "slide.pp.high",
    "slide.pp.med",
    "slide.pp.low",
    "slide.pp.neg",
    "field.name",
    "count.pos",
    "count.total",
    "count.pos.first.100",
    "field.x",
    "field.y",
    "field.diameter",
    "comment.slide",
    "comment.field")

ki67p3b.raw <- as.data.frame(ki67p3b.raw,stringsAsFactors=FALSE)

# add 3A group number
lookup_3a_group_num <- function(deid) {
  # first, deal with labs who did NOT participate in 3a study:
  return(switch(deid,
    "Q"="1", # Anna Ehinger
    "W"="3", # Bert van der Vegt
    "X"="1", # Sunil Badve
    unique(ki67p3.raw.d$group.num[which(ki67p3.raw.d$deid==deid)])
  ))
}
ki67p3b.raw$group.num.3a <- sapply(ki67p3b.raw$deid,lookup_3a_group_num)

# reorder variables:
ki67p3b.raw <- ki67p3b.raw[,c(
  "deid",
  "institution",
  "group.num",
  "group.num.3a",
  "surgical.number",
  "specimen.type",
  "slide.id",
  "slide.pp.high",
  "slide.pp.med",
  "slide.pp.low",
  "slide.pp.neg",
  "field.name",
  "count.pos",
  "count.total",
  "count.pos.first.100",
  "field.x",
  "field.y",
  "field.diameter",
  "comment.slide",
  "comment.field"
)]

###########################
### DATA CHANGES        ###
# need to make changes to all exported objects!

# two cases with specified percentages sum to > 100, need to scale them back
correct.pp <- function(deid.to.change, surgical.number.to.change, specimen.type.to.change) {
  ki67p3b.raw.index <- which(
    ki67p3b.raw$deid==deid.to.change & 
    ki67p3b.raw$surgical.number==surgical.number.to.change & 
    ki67p3b.raw$specimen.type==specimen.type.to.change)
  pp.col.names <- c("slide.pp.high","slide.pp.med","slide.pp.low","slide.pp.neg")
  
  cat(paste0(
    "DATA CHANGE (",deid.to.change,": ",surgical.number.to.change,", surgery): given percentages (",
    paste(paste(pp.col.names,round(as.numeric(ki67p3b.raw[ki67p3b.raw.index[1],pp.col.names])),sep=":"),collapse="/"),
    ") sum to > 100%.  Scale them so that sum = 100%\n")
  )

  old.sum <- sum(as.numeric(ki67p3b.raw[ki67p3b.raw.index[1],pp.col.names]))
  corr.factor <- 100/old.sum
  
  # change ki67p3b.raw
  prev.d <- ki67p3b.raw
  ki67p3b.raw[ki67p3b.raw.index,pp.col.names] <<- sapply(ki67p3b.raw[ki67p3b.raw.index,pp.col.names],function(x){as.numeric(x)*corr.factor})
  new.d <- ki67p3b.raw
  prev.d$unique_id <- paste(prev.d$deid, prev.d$surgical.number, prev.d$field.x, prev.d$field.y)
  new.d$unique_id  <- paste(new.d$deid,  new.d$surgical.number,  new.d$field.x,  new.d$field.y)
  cat("showing changes ...\n")
  QCFunctions::CompareDb(prev.d, new.d,"unique_id")
  
  pp.per.field.type <- as.numeric(ki67p3b.raw[ki67p3b.raw.index[1],pp.col.names])
  pp.per.field.type.select.no.zero <- which(pp.per.field.type!=0)
  
  if (specimen.type.to.change=="surgery") { # no need to change hot-spot or unweighted global score
    # ki67p3b.wg.ws 
    scores.per.field.type <- sapply(c("high","medium","low","negative")[pp.per.field.type.select.no.zero],function(x){
      select.indexes <- intersect(ki67p3b.raw.index, which(ki67p3b.raw$field.name==x))   
      return(sum(as.numeric(ki67p3b.raw[select.indexes,"count.pos.first.100"]))/sum(sapply(as.numeric(ki67p3b.raw[select.indexes,"count.total"]),function(y){min(100,y)})))
    })
    old.score <- ki67p3b.wg.ws[surgical.number.to.change,deid.to.change]
    new.score <- sum(scores.per.field.type * pp.per.field.type[pp.per.field.type.select.no.zero])
    cat(paste0("CHANGING ki67p3b.wg.ws(",deid.to.change,"/",surgical.number.to.change,"): ", old.score, " -> ", new.score,"\n"))
    ki67p3b.wg.ws[surgical.number.to.change,deid.to.change] <<- new.score
  }
} 

correct.pp("X","TB196","surgery")
correct.pp("D","TB016","surgery")

### END OF DATA CHANGES ###
###########################

source("qc.R")

# add dictionary
source("add_dictionary.R")

# export data to for R package
cat("Exporting data for R package ... \n")
kd <- ki67p3b.raw
devtools::use_data(ki67p3b.raw, overwrite = TRUE)
devtools::use_data(ki67p3b.hp.bx, overwrite = TRUE)
devtools::use_data(ki67p3b.hp.ws, overwrite = TRUE)
devtools::use_data(ki67p3b.ug.bx, overwrite = TRUE)
devtools::use_data(ki67p3b.ug.ws, overwrite = TRUE)
devtools::use_data(ki67p3b.wg.bx, overwrite = TRUE)
devtools::use_data(ki67p3b.wg.ws, overwrite = TRUE)
# archive (i.e. copy) to export_logs
save(kd,file=file.path(getwd(),"export_logs",paste("kd_",format(Sys.Date(),format="%Y-%m-%d"),".rda",sep="")))
# export text file!!!
write.table(
  kd,
  file=file.path(getwd(),"export_logs",paste("ki67p3b_n",nrow(kd),"_",format(Sys.Date(),format="%Y-%m-%d"),".txt",sep="")),
  sep="\t",
  col.names=TRUE,
  row.names=FALSE
)
cat("done.",date(),"\n")
