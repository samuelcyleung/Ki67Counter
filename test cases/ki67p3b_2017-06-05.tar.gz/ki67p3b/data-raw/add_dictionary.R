# add dictionary to Ki67 phase 3B data set
# 
# Author: samuelc
###############################################################################


comment(ki67p3b.raw) <- paste0("Ki67 phase 3B raw (each row correponds to one field) i.e. multiple rows per case/lab.  Data packaged on ",format(Sys.Date(),format="%Y-%m-%d"))
comment(ki67p3b.hp.bx) <- paste0("Ki67 phase 3B hot-spot on core-cut.  Data packaged on ",format(Sys.Date(),format="%Y-%m-%d"))
comment(ki67p3b.hp.ws) <- paste0("Ki67 phase 3B hot-spot on whole section.  Data packaged on ",format(Sys.Date(),format="%Y-%m-%d"))
comment(ki67p3b.ug.bx) <- paste0("Ki67 phase 3B unweighted global on core-cut.  Data packaged on ",format(Sys.Date(),format="%Y-%m-%d"))
comment(ki67p3b.ug.ws) <- paste0("Ki67 phase 3B unweighted global on whole section.  Data packaged on ",format(Sys.Date(),format="%Y-%m-%d"))
comment(ki67p3b.wg.bx) <- paste0("Ki67 phase 3B weighted global on core-cut.  Data packaged on ",format(Sys.Date(),format="%Y-%m-%d"))
comment(ki67p3b.wg.ws) <- paste0("Ki67 phase 3B weighted global on whole section.  Data packaged on ",format(Sys.Date(),format="%Y-%m-%d"))
