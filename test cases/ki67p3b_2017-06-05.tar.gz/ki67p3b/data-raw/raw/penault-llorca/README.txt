Sam Leung note 2016-12-01:

manually removed new line character after comments on 

"scoring_session_scores_id142.txt"
"scoring_session_nuclei_selections_id142.txt"

- slide TB405


vi commands:

:%s/assess\n/assess 
