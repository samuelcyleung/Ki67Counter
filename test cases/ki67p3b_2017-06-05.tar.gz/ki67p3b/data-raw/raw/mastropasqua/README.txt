Sam Leung note 2016-11-29:

manually removed new line character after comments on 

"scoring_session_nuclei_selections_id257.txt"

- slide 23


vi commands:

:%s/regards\n/regards 
:%s/unreproduceability\n/unreproduceability 