# parse scores for Ki67 phase 3b
# - this script is to be sourced by data_setup.R
# Author: samuelc
###############################################################################


###############################
### helper functions        ###
# determine group number
get.group.number <- function(x) {
	if (length(grep("slice s3",x))>0) {
		return(1) # group 1 is slice 3
	} else if (length(grep("slice s4",x))>0) {
		return(2) # group 2 is slice 4
	} else if (length(grep("slice s5",x))>0) {
		return(3) # group 3 is slice 5
	} else if (length(grep("slice s6",x))>0) {
		return(4) # group 4 is slice 6
	} else {
		cat("ERROR unknown group! ",x,"\n")
	}
}

# parse a component of a score e.g. hotspot, high, medium, low
parse.comp <- function(x) {
	name <- strsplit(x,"\\[")[[1]][1]
	comp <- strsplit(strsplit(x,":")[[1]][3],",")[[1]]
	count.pos <- as.numeric(strsplit(comp[1],"\\(\\+ve\\)")[[1]])
	count.total <- as.numeric(strsplit(comp[3],"\\(")[[1]][1])
	coord <- sapply(strsplit(strsplit(strsplit(x,":")[[1]][2],"\\]")[[1]][1],",")[[1]],as.numeric,USE.NAMES=FALSE)
	
	return(list(
					"name"=name,
					"count.pos"=count.pos,
					"count.total"=count.total,
					"x"=coord[1],
					"y"=coord[2],
					"diameter"=coord[3],
					"comment"=NA # to be filled in later
			))
}

# function to parse the score
# - input is a single row
parse.score <- function(input) {
	x <- input[4]
	# assume x[1] = slide id
	#        x[2] = surgical number
	#        x[3] = score
	
	# need to figure out all comments first, record them and REMOVE THEM!!!
	# 1. comment on whole slide
	comment.indexes <- biostatUtil::indexOf(x,"###")
	comment.on.whole.slide <- substr(x,comment.indexes[1]+3,comment.indexes[2]-1)
    comment.on.whole.slide <- ""
	# remove comment on whole slide
	x <- paste(substr(x,1,comment.indexes[1]-1), substr(x,comment.indexes[2]+3,nchar(x)),sep="")
	# 2. comment on hot-spot
	comment.indexes <- biostatUtil::indexOf(x,"###") 
	comment.on.hotspot <- substr(x,comment.indexes[1]+3,comment.indexes[2]-1)
	x <- paste(substr(x,1,comment.indexes[1]-1), substr(x,comment.indexes[2]+3,nchar(x)),sep="")
	# 3. comment on fields
	comment.on.fields <- c()
	comment.indexes <- biostatUtil::indexOf(x,"###") 
	while(length(comment.indexes)>1) { # the comment tag ### must comes in pair
		comment.on.fields <- c(comment.on.fields, substr(x,comment.indexes[1]+3,comment.indexes[2]-1))
		x <- paste(substr(x,1,comment.indexes[1]-1), substr(x,comment.indexes[2]+3,nchar(x)),sep="")
		comment.indexes <- biostatUtil::indexOf(x,"###") 
	}

	group.num <- get.group.number(x)
	
	x <- sapply(strsplit(x,";")[[1]],stringr::str_trim,USE.NAMES=FALSE)	
	
	slide.pps.comp <-as.numeric(strsplit(strsplit(x[1],":|;")[[1]][2],"/")[[1]])
	slide.pps <- list("high"=slide.pps.comp[1],"medium"=slide.pps.comp[2],"low"=slide.pps.comp[3],"negative"=slide.pps.comp[4])
	
	hotspot <- parse.comp(x[2])
	hotspot$comment <- comment.on.hotspot
	
	fields <- c()
	for (i in 3:(length(x))) {		
		fields <- c(fields, list(parse.comp(x[i])))
	}
	for (i in 1:length(fields)) {
		fields[[i]]$comment <- comment.on.fields[i]
	}
	
	return(list(
					"group.num"=group.num,
					"surgical.number"=stringr::str_trim(input[2]),
					"slide.id"=as.numeric(input[1]),
					"slide.pps"=slide.pps,
					"hotspot"=hotspot,
					"fields"=fields,
					"comment.on.whole.slide"=comment.on.whole.slide))
}

# function to parse the score from raw counts
# - input is a data.frame
parse.score.from.raw.count <- function(input, summary.input) {
  surgical.numbers <- unique(input$Surgical.number)
  scores <- input[match(surgical.numbers,input$Surgical.number),"Score"]
  slide.ids <- summary.input[match(surgical.numbers,summary.input$Surgical.number),"Whole.section.image.ID"]
  
  comments.on.whole.slide <- c()
  comments.on.hotspot <- c()
  comments.on.fields <- list()
  
  # need to figure out all comments first, record them and REMOVE THEM!!!
  for (i in 1:length(scores)) {
    x <- scores[i]
    # 1. comment on whole slide
    comment.indexes <- biostatUtil::indexOf(x,"###")
    comments.on.whole.slide <- c(comments.on.whole.slide,substr(x,comment.indexes[1]+3,comment.indexes[2]-1))
    comment.on.whole.slide <- ""
    # remove comment on whole slide
    x <- paste(substr(x,1,comment.indexes[1]-1), substr(x,comment.indexes[2]+3,nchar(x)),sep="")
    # 2. comment on hot-spot
    comment.indexes <- biostatUtil::indexOf(x,"###") 
    comments.on.hotspot <- c(comments.on.hotspot,substr(x,comment.indexes[1]+3,comment.indexes[2]-1))
    x <- paste(substr(x,1,comment.indexes[1]-1), substr(x,comment.indexes[2]+3,nchar(x)),sep="")
    # 3. comment on fields
    comment.on.fields <- c()
    comment.indexes <- biostatUtil::indexOf(x,"###") 
    while(length(comment.indexes)>1) { # the comment tag ### must comes in pair
      comment.on.fields <- c(comment.on.fields, substr(x,comment.indexes[1]+3,comment.indexes[2]-1))
      x <- paste(substr(x,1,comment.indexes[1]-1), substr(x,comment.indexes[2]+3,nchar(x)),sep="")
      comment.indexes <- biostatUtil::indexOf(x,"###") 
    }
    comments.on.fields[[i]] <- comment.on.fields
    scores[i] <- x
  }
  
  group.nums <- sapply(scores,get.group.number,USE.NAMES=FALSE)
  
  # slide.id not available
  slide.pps <- lapply(sapply(scores,stringr::str_trim,USE.NAMES=FALSE), function(x){
    slide.pps.comp <-as.numeric(strsplit(strsplit(x[1],":|;")[[1]][2],"/")[[1]])
    return(list("high"=slide.pps.comp[1],"medium"=slide.pps.comp[2],"low"=slide.pps.comp[3],"negative"=slide.pps.comp[4]))
  })
   
  # hots-spot
  hps <- list()
  for (i in 1:length(surgical.numbers)) {
    surgical.number <- surgical.numbers[i]
    temp <- input[input$Surgical.number==surgical.number & input$Whole.section.field.level=="hot-spot",]
    hps[[i]] <- list(
      "name"="hot-spot",
      "count.pos"=sum(temp$Nuclei.selection..state.=="p"),
      "count.pos500"=sum(temp$Nuclei.selection..state.[1:min(500,nrow(temp))]=="p"), # first up to 500 nuclei (could be less)
      "count.total"=nrow(temp),
      "x"=unique(temp$Whole.section.field..x.coordinate.),
      "y"=unique(temp$Whole.section.field..y.coordinate.),
      "diameter"=unique(temp$Whole.section.field..diameter.pixel.),
      "comment"=comments.on.hotspot[i]
    )
  }

  # fields
  fields <- list()
  for (i in 1:length(surgical.numbers)) {
    surgical.number <- surgical.numbers[i]
    temp <- input[input$Surgical.number==surgical.number & input$Whole.section.field.level!="hot-spot",]
    temp$region_id <- paste(temp$Whole.section.field..x.coordinate.,temp$Whole.section.field..y.coordinate.,sep="_")
    fields[[i]] <- lapply(unique(temp$region_id),function(region_id){
      temp2 <- temp[temp$region_id==region_id,]
      #cat(length(comments.on.fields[[i]]))
      return(list(
        "name"=unique(temp2$Whole.section.field.level),
        "count.pos"=sum(temp2$Nuclei.selection..state.=="p"),
        "count.pos100"=sum(temp2$Nuclei.selection..state.[1:min(100,nrow(temp2))]=="p"),
        "count.total"=nrow(temp2),
        "x"=unique(temp2$Whole.section.field..x.coordinate.),
        "y"=unique(temp2$Whole.section.field..y.coordinate.),
        "diameter"=unique(temp2$Whole.section.field..diameter.pixel.),
        "comment"=comments.on.fields[[i]][which(unique(temp$region_id)==region_id)]
      ))
    })
  }

  result <- list()
  for (i in 1:length(group.nums)) {
    result[[i]] <- list(
        "group.num"=group.nums[[i]],
        "surgical.number"=surgical.numbers[[i]],
        "slide.id"=slide.ids[[i]],
        "slide.pps"=slide.pps[[i]],
        "hotspot"=hps[[i]],
        "fields"=fields[[i]],
        "comment.on.whole.slide"=comments.on.whole.slide[i]    
    )
  }
  return(result)
}

# calculate component's percent positive
cal.hotspot.comp.pp <- function(x, first500=FALSE) {
  x <- x$hotspot; 
  if (first500) {
    return(x$count.pos500/min(x$count.total,500)*100)
  } else {
    return(x$count.pos/x$count.total*100)
  }
}

# function to calculate unweighted global scores from fields
get.unweighted.global.score.from.fields <- function(input, first100=FALSE) {
  if (first100) {
    return(sum(sapply(input$fields,function(x){return(x$count.pos100)})) / sum(sapply(input$fields,function(x){return(min(100,x$count.total))})) * 100) 
  } else {
	return(sum(sapply(input$fields,function(x){return(x$count.pos)})) / sum(sapply(input$fields,function(x){return(x$count.total)})) * 100)
  }
}

# function to calculate weighted global scores from fields
get.weighted.global.score.from.fields <- function(input, first100=FALSE) {
	# first need to get the percent high/low/med/neg
	pp.lookup <- input$slide.pps
	fields <- input$fields
	composite.score <- 0
    
    for (field.type in names(pp.lookup)) {
      if (pp.lookup[[field.type]]>0) {
        count.pos   <- sum(sapply(fields,function(field){ifelse(field$name==field.type,ifelse(first100,field$count.pos100,field$count.pos),0)}))
        total.count <- sum(sapply(fields,function(field){ifelse(field$name==field.type,ifelse(first100,min(100,field$count.total),field$count.total),0)}))
        composite.score <- composite.score + ifelse(total.count==0,0,pp.lookup[[field.type]]*count.pos/total.count)
      }
    }
    
	return(composite.score)
}

### end of helper functions ###
###############################

# parse scores
for (lab.id in WS.LAB.IDS) {assign(paste(tolower(lab.id),".ws",sep=""),apply(get(paste(tolower(lab.id),".raw.ws",sep="")), 1,parse.score))}
for (lab.id in WS.LAB.IDS) {assign(paste(tolower(lab.id),".hp.ws",sep=""),sapply(get(paste(tolower(lab.id),".ws",sep="")),cal.hotspot.comp.pp))}
for (lab.id in WS.LAB.IDS) {assign(paste(tolower(lab.id),".ug.ws",sep=""),sapply(get(paste(tolower(lab.id),".ws",sep="")),get.unweighted.global.score.from.fields))}
for (lab.id in WS.LAB.IDS) {assign(paste(tolower(lab.id),".wg.ws",sep=""),sapply(get(paste(tolower(lab.id),".ws",sep="")),get.weighted.global.score.from.fields))}

for (lab.id in BX.LAB.IDS) {assign(paste(tolower(lab.id),".bx",sep=""),apply(get(paste(tolower(lab.id),".raw.bx",sep="")), 1,parse.score))}
for (lab.id in BX.LAB.IDS) {assign(paste(tolower(lab.id),".hp.bx",sep=""),sapply(get(paste(tolower(lab.id),".bx",sep="")),cal.hotspot.comp.pp))}
for (lab.id in BX.LAB.IDS) {assign(paste(tolower(lab.id),".ug.bx",sep=""),sapply(get(paste(tolower(lab.id),".bx",sep="")),get.unweighted.global.score.from.fields))}
for (lab.id in BX.LAB.IDS) {assign(paste(tolower(lab.id),".wg.bx",sep=""),sapply(get(paste(tolower(lab.id),".bx",sep="")),get.weighted.global.score.from.fields))}

# parse scores from raw counts
for (lab.id in WS.LAB.IDS) {assign(paste(tolower(lab.id),".ws.ct",sep=""),parse.score.from.raw.count(get(paste(tolower(lab.id),".raw.ct.ws",sep="")), get(paste(tolower(lab.id),".raw.ws",sep=""))))}
for (lab.id in WS.LAB.IDS) {assign(paste(tolower(lab.id),".hp.ws.ct",sep=""),sapply(get(paste(tolower(lab.id),".ws.ct",sep="")),cal.hotspot.comp.pp))}
for (lab.id in WS.LAB.IDS) {assign(paste(tolower(lab.id),".ug.ws.ct",sep=""),sapply(get(paste(tolower(lab.id),".ws.ct",sep="")),get.unweighted.global.score.from.fields))}
for (lab.id in WS.LAB.IDS) {assign(paste(tolower(lab.id),".wg.ws.ct",sep=""),sapply(get(paste(tolower(lab.id),".ws.ct",sep="")),get.weighted.global.score.from.fields))}

for (lab.id in BX.LAB.IDS) {assign(paste(tolower(lab.id),".bx.ct",sep=""),parse.score.from.raw.count(get(paste(tolower(lab.id),".raw.ct.bx",sep="")), get(paste(tolower(lab.id),".raw.bx",sep=""))))}
for (lab.id in BX.LAB.IDS) {assign(paste(tolower(lab.id),".hp.bx.ct",sep=""),sapply(get(paste(tolower(lab.id),".bx.ct",sep="")),cal.hotspot.comp.pp))}
for (lab.id in BX.LAB.IDS) {assign(paste(tolower(lab.id),".ug.bx.ct",sep=""),sapply(get(paste(tolower(lab.id),".bx.ct",sep="")),get.unweighted.global.score.from.fields))}
for (lab.id in BX.LAB.IDS) {assign(paste(tolower(lab.id),".wg.bx.ct",sep=""),sapply(get(paste(tolower(lab.id),".bx.ct",sep="")),get.weighted.global.score.from.fields))}

# double check to make sure *.hp.ws.ct are exactly the same as *.ws.ct
check <- TRUE
for (lab.id in WS.LAB.IDS){
  for (score.type in c("hp","ug","wg")) {
    a <- get(paste(tolower(lab.id),".",score.type,".ws",sep="")) 
    b <- get(paste(tolower(lab.id),".",score.type,".ws.ct",sep=""))
    assert_that(sum(a==b)==30)
    check <- check & (sum(a==b)==30)
  }
}
cat("# double check to make sure *.ws are exactly the same as *.ws.ct ...",check,"\n")
check <- TRUE
for (lab.id in BX.LAB.IDS){
  for (score.type in c("hp","ug","wg")) {
    a <- get(paste(tolower(lab.id),".",score.type,".bx",sep="")) 
    b <- get(paste(tolower(lab.id),".",score.type,".bx.ct",sep=""))
    assert_that(sum(a==b)==30)
    check <- check & (sum(a==b)==30)
  }
}
cat("# double check to make sure *.bx are exactly the same as *.bx.ct ...",check,"\n")
# double check to make sure surgical.number same for all data
check <- TRUE
temp <- sapply(get(paste(tolower(WS.LAB.IDS[1]),".ws",sep="")),function(x){x$surgical.number})
for (i in 2:length(WS.LAB.IDS)) {
  check <- check & sum(temp==sapply(get(paste(tolower(WS.LAB.IDS[i]),".ws",sep="")),function(x){x$surgical.number}))==length(temp)
}
temp <- sapply(get(paste(tolower(BX.LAB.IDS[1]),".bx",sep="")),function(x){x$surgical.number})
for (i in 2:length(BX.LAB.IDS)) {
  check <- check & sum(temp==sapply(get(paste(tolower(BX.LAB.IDS[i]),".bx",sep="")),function(x){x$surgical.number}))==length(temp)
}
cat("# double check to make sure surgical.number same for all data ...",check,"\n")

# scores from first 500/100 nuclei
for (lab.id in WS.LAB.IDS) {assign(paste(tolower(lab.id),".hp.ws",sep=""),sapply(get(paste(tolower(lab.id),".ws.ct",sep="")),cal.hotspot.comp.pp, first500=TRUE))}
for (lab.id in WS.LAB.IDS) {assign(paste(tolower(lab.id),".ug.ws",sep=""),sapply(get(paste(tolower(lab.id),".ws.ct",sep="")),get.unweighted.global.score.from.fields, first100=TRUE))}
for (lab.id in WS.LAB.IDS) {assign(paste(tolower(lab.id),".wg.ws",sep=""),sapply(get(paste(tolower(lab.id),".ws.ct",sep="")),get.weighted.global.score.from.fields, first100=TRUE))}

for (lab.id in BX.LAB.IDS) {assign(paste(tolower(lab.id),".hp.bx",sep=""),sapply(get(paste(tolower(lab.id),".bx.ct",sep="")),cal.hotspot.comp.pp, first500=TRUE))}
for (lab.id in BX.LAB.IDS) {assign(paste(tolower(lab.id),".ug.bx",sep=""),sapply(get(paste(tolower(lab.id),".bx.ct",sep="")),get.unweighted.global.score.from.fields, first100=TRUE))}
for (lab.id in BX.LAB.IDS) {assign(paste(tolower(lab.id),".wg.bx",sep=""),sapply(get(paste(tolower(lab.id),".bx.ct",sep="")),get.weighted.global.score.from.fields, first100=TRUE))}

#for (lab.id in WS.LAB.IDS){
#  for (score.type in c("hp","ug","wg")) {
#    a <- get(paste(tolower(lab.id),".",score.type,".ws",sep="")); b <- get(paste(tolower(lab.id),".",score.type,".ws.ct",sep=""))
#    if(sum(a==b)!=30) {cat(lab.id,score.type,"\n")}
#  }
#}


