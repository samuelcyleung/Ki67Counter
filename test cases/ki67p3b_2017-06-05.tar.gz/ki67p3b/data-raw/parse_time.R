# figure out the time data from Ki67 phase 3b
# 
# Author: samuelc
###############################################################################

#sql.d <- read.csv(file="raw//sql_time_2016-07-27.csv", header=T, as.is=T)
sql.d <- read.csv(file="raw//sql_time_2016-08-17.csv", header=T, as.is=T)
# exclude the beta test cases
sql.d <- sql.d[grep("MIB1",sql.d$name),]

# remove all the phase 3a slides
sql.d <- sql.d[!sapply(sql.d$name,startsWith,"TB"),]

sql.d$case.id <- as.numeric(sapply(sql.d$name,function(x){return(strsplit(x,"_")[[1]][1])}))
sql.d$slide.type <- "biopsy"
sql.d$slide.type[sql.d$case.id<40] <- "surgery"

# set all negative times to NA - these capture time data are not reliable
time.var.names <- c("time_select_hotspot","time_estimate","time_select_fields")
for (var.name in time.var.names) {
	sql.d[sapply(sql.d[,var.name],biostatUtil::startsWith,"-"),var.name] <- NA
}
# transform time to seconds
for (var.name in time.var.names) {
	sql.d[,var.name] <- sapply(sql.d[,var.name],function(x){
		temp <- as.numeric(strsplit(x,":")[[1]])
		return(sum(temp*c(3600,60,1)))
	})
}

cat("### biopsy time ...\n")
print(summary(sql.d[sql.d$slide.type=="biopsy",time.var.names]))
cat("\n\n")

cat("### whole section time ...\n")
print(summary(sql.d[sql.d$slide.type=="surgery",time.var.names]))
cat("\n\n")


