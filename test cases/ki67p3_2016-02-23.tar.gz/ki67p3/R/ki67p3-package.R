#' Ki67-QC phase 3 dataset package
#'
#' @docType package
#' @name ki67p3
NULL

#' Ki67-QC phase 3 dataset (packaged 2015-09-08)
#'
#' @format raw data; a data frame with 3230 rows and 17 columns; each row represents one field (i.e. multiple rows per case); 
#' @name ki67p3.raw.d
NULL

#' Ki67-QC phase 3 dataset (packaged 2015-09-08)
#'
#' @format hot-spot scores; a data frame with 30 rows and 22 columns; each row represents one case, each column represents one laboratory
#' @name ki67p3.hp.d
NULL

#' Ki67-QC phase 3 dataset (packaged 2015-09-08)
#'
#' @format unweighted global scores; a data frame with 30 rows and 22 columns; each row represents one case, each column represents one laboratory
#' @name ki67p3.ug.d
NULL

#' Ki67-QC phase 3 dataset (packaged 2015-09-08)
#'
#' @format weighted global scores; a data frame with 30 rows and 22 columns; each row represents one case, each column represents one laboratory
#' @name ki67p3.wg.d
NULL

#' Ki67-QC phase 3 dataset (packaged 2015-09-08)
#'
#' @format clinical data; a data frame with 30 rows and 5 columns; each row represents one case
#' @name ki67p3.clin.d
NULL
